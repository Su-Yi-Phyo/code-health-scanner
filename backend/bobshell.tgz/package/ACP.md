# Bob Shell as an ACP Agent

`bob acp` starts Bob Shell as an [Agent Client Protocol](https://agentclientprotocol.com) server over stdio. Any ACP client (e.g. the Zed editor) can spawn it and drive Bob sessions from the editor UI.

## Quick start (Zed)

Add to Zed's `settings.json`:

```json
{
    "agent_servers": {
        "Bob": {
            "command": "bob",
            "args": ["acp"]
        }
    }
}
```

Open the Agent panel, pick **Bob**, and start a thread.

## Authentication

- With the provider's API key environment variable, no login is needed.
- Otherwise Bob uses SSO. The first `session/new` fails with `auth_required`; the editor shows an **Authenticate** action that opens your browser. Tokens are stored, so this is a one-time step per machine.
- Headless/SSH: the login URL is logged to stderr. Run with `--log-level info` and check the editor's agent server logs to copy it.

## Flags

| Flag                  | Description                                                     |
| --------------------- | --------------------------------------------------------------- |
| `--log-level <level>` | `debug`, `info`, `warn`, `error`, `silent` (or `BOB_LOG_LEVEL`) |
| `--trust`             | Trust each workspace opened by the ACP server                   |
| `--auto-approve`      | Skip all permission prompts and approve every tool call         |
| `--disable-mcp`       | Disable MCP server initialization                               |
| `--disable-subagents` | Disable subagent tool registration                              |
| `--accept-license`    | Accept the license before starting the ACP server               |

Run `bob --show-license acp` to show the license file paths and exit.

## Permissions

Read-only tools run without prompting. Every other tool call asks the client for permission with four options: **Allow once**, **Always allow**, **Reject**, **Always reject**. "Always" decisions are remembered for the rest of the session, keyed by tool name. `--auto-approve` disables prompting entirely.

## Features

- **Session history** — compatible clients can list Bob's existing file-based sessions, page through recent history, and delete sessions from the shared Bob store.
- **Live session titles** — clients receive title and last-activity updates after successful prompt turns.
- **Session resume** — `session/resume` restores a thread without replaying already-visible messages; `session/load` remains available for clients that need full history replay, including tool calls, diffs, and the last plan state.
- **Inline diffs** — file edits stream as diff content with file locations, so editors can render diffs and follow the agent.
- **Plan panel** — Bob's todo list updates stream as ACP plan updates.
- **Image prompts** — pasted images are forwarded to the model.
- **Client MCP servers** — MCP servers configured in the editor over stdio or Streamable HTTP are registered into the session.

## Caveats

- Each ACP session runs its own Bob harness, including its configured MCP servers.
- Legacy two-endpoint HTTP+SSE MCP servers supplied by an ACP client are rejected; use Streamable HTTP instead.
- Model selection (`session/set_model`) is not supported; use modes instead.
- Bob executes commands in its own shell; ACP client terminals are not used.

## Task transfer (Bob extension)

Bob advertises `agentCapabilities._meta["bob/extensions"] = { "version": 1 }`.
This version identifies Bob’s ACP extension contract. The task-transfer requests carry persisted task state; standard ACP UI updates are unchanged.

### Export

```json
{
    "jsonrpc": "2.0",
    "id": 10,
    "method": "_bob/task/export",
    "params": { "sessionId": "existing-bob-task-id" }
}
```

The result is the same `ProjectExport` JSON produced by the IDE's single-task export:
`{ version: 1, exportedAt, workspace, tasks }`. It includes the selected task's stored messages
and metadata. Like the IDE export, it does not collect child tasks. The task need not be open
in this ACP process. A missing task returns `-32600`.

### Import

Call `_bob/task/import` with `{ "cwd": "/absolute/destination", "snapshot": <export result> }`.
The response is `{ "sessionIds": ["new-task-id", ...] }`.

This calls the same shared importer as the IDE. Single-task and workspace JSON exports are
accepted. Each import creates paused copies with new task and message IDs; importing the
same file twice creates two copies. Existing tasks are not overwritten. All writes are in
one transaction. Invalid input returns `-32602`.

Import does not open a session. Use a returned ID with `session/load` to replay history, or
`session/resume` to continue without replay, supplying `cwd` and `mcpServers` as usual.
Workspace files, credentials, and runtime configuration must be provided separately.

The shared importer updates both the task's workspace column and its saved environment for the
destination. Historical messages and embedded paths in their content are preserved.
